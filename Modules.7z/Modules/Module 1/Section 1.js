var selModuleObj;  // making Module selection element global

//function to calculate the module score and display the results in an alert box
function calculateScore(){
	var empId = parseInt(document.getElementById("txtEmpNoId").value);
	var empName = document.getElementById("txtEmpNameId").value;
	var mptMarks = eval(document.getElementById("noMptMarksId").value);
	var mttMarks = eval(document.getElementById("noMttMarksId").value);
	var asnmtMarks = eval(document.getElementById("noAsnmtMarksId").value);
	var perMptMarks = mptMarks; //Total out of 70 and weightage 70%
	var perMttMarks = (mttMarks*3)/8; //Total out of 40 and weightage 15%
	var perAsnmtMarks = asnmtMarks; //Total out of 15 and weightage 15%
	var  totalMarks =  perMptMarks+perAsnmtMarks+perMttMarks; //Score calculated out of 100%
	alert(empId+" : "+empName+" Your Module Score is "+totalMarks+" / 100");
}

//function to fill the Choose Module selection box dynamically based on the user's selection of domain
function fillModule(listindex)
{
		selModuleObj=document.getElementById("selModuleId"); 
		if(listindex=="JEE"){
						 selModuleObj.options[0]=new Option("Core Java","Core Java");
						 selModuleObj.options[1]=new Option("Servlet-JSP","Servlet-JSP");
						 selModuleObj.options[2]=new Option("Spring","Spring");
		}
		else if(listindex==".NET"){
						 selModuleObj.options[0]=new Option("C#","C#");
						 selModuleObj.options[1]=new Option("ADO.NET","ADO.NET");
						 selModuleObj.options[2]=new Option("ASP.NET","ASP.NET");					
		}
		else{
						selModuleObj.options[0]=new Option("Select Module","none");
						selModuleObj.remove(1);
						selModuleObj.remove(1);
		}
}
			