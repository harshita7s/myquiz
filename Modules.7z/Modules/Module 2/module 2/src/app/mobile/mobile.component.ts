import { Component, OnInit } from '@angular/core';
import {Mobile} from '../mobile';
import {MobileService} from '../mobile.service'
import {HttpClient} from '@angular/common/http'


@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})


export class MobileComponent implements OnInit {

  /*Mobile type array to store the json data*/
  mobile:Mobile[]=[]; 
  
  /*Class constructor with dependency injection for HttpClient*/
  constructor(private httpClient:HttpClient,private mobileService:MobileService) 
  {

  }
  
  /*Use get() of httpClient to fetch the json data*/
  ngOnInit() {
    this.httpClient.get('../assets/mobile.json').subscribe(
        data=>{
          this.mobile=data as Mobile[];
        }
    );
  }

  /*Method to delete the selected mobile data on delete button click*/
  deleteMobile(index:number):void{
      this.mobile.splice(index,1);
  }

  /*Method to sort the data based on mobile Id*/
  sortById(){
    this.mobile.sort((x,y)=>(x.mobId-y.mobId));
  }

  /*Method to sort the data based on mobile Name*/
  sortByName(){
    this.mobile.sort((x,y)=>((x.mobName == y.mobName) ? 0 : ((x.mobName > y.mobName) ? 1 : -1 )));
  }

  /*Method to sort the data based on mobile Price*/
  sortByPrice(){
    this.mobile.sort((x,y)=>(x.mobPrice-y.mobPrice));
  }

}
