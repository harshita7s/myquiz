import { Injectable,OnInit } from '@angular/core';
import {Mobile} from './mobile';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})

export class MobileService {
  
  constructor(private httpClient:HttpClient) { }
  mobiles:Mobile[]=[];
  ngOnInit(){
    this.httpClient.get('./assets/mobile.json').subscribe(
        data=>{
          this.mobiles=data as Mobile[];
        }
    );
  }
  
  getMobiles():Mobile[]{
    return this.mobiles;
  }

}
