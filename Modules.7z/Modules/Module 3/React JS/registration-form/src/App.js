import React, { Component } from 'react';
import './App.css';

class App extends Component {
  state = {
    user:
    {
      name:"",
      email:"",
      mobile:"",
      address:"",
      purpose:"",
      date:"",
      isLoggedIn:false
    },
  }
  
  /*--------------Handling changes and storing the form values in state---------------*/
  handleChangeUname = (e)=>{
    const user = Object.assign({},this.state.user)
    user.name = e.target.value;
    this.setState({user:user})
  }
  handleChangeUemail = (e)=>{
    const user = Object.assign({},this.state.user)
    user.email = e.target.value;
    this.setState({user:user})
  }
  handleChangeUmobile = (e)=>{
    const user = Object.assign({},this.state.user)
    user.mobile = e.target.value;
    this.setState({user:user})
  }
  handleChangeUaddress = (e)=>{
    const user = Object.assign({},this.state.user)
    user.address = e.target.value;
    this.setState({user:user})
  }
  handleChangeUpurpose = (e)=>{
    const user = Object.assign({},this.state.user)
    user.purpose = e.target.value;
    this.setState({user:user})
  }
  handleChangeUdate = (e)=>{
    const user = Object.assign({},this.state.user)
    user.date = e.target.value;
    this.setState({user:user})
  }
  /*-----------------------------------------------------------------------------*/



  /*--------------Handling form submit and delete information---------------*/
  login = (e)=>{
    e.preventDefault()
    const user = Object.assign({},this.state.user)
    if(user.name==''||user.mobile==''||user.date==''){
      alert("Please fill the mandatory details");
      return;
    }
    if(!user.mobile.match(/[0-9]{10}/)){
      alert("Mobile Number should be of 10 digits");
      return;
    }
    user.isLoggedIn = true
    this.setState({user:user})
  }

  delete = (e)=>{
    e.preventDefault()
    alert("Customer Information Deleted Successfully");
    const user = Object.assign({},this.state.user)
    user.isLoggedIn = false
    user.name='';
    user.email='';
    user.mobile='';
    user.address='';
    user.purpose='';
    user.date='';
    this.setState({user:user})
  }
  /*-----------------------------------------------------------------------------*/




  //Render method to display the registration form
  render() {

    /*Initially display the registration form*/
    if(!this.state.user.isLoggedIn){
      return (
      <div className="panel con">
        <div className="panel-heading panel-primary"><h1>Customer Registration Form</h1></div>
        <div className="panel-body">
          <form onSubmit={this.handleSubmit}>

            <div className="form-group">
                {/*<label>UserName</label>*/}
                <span id="red">*</span>
                <input
                  autoFocus
                  type="text"
                  value={this.state.user.name}
                  placeholder="Username"
                  onChange={this.handleChangeUname.bind(this)}
                />
              </div>

              <div className="form-group">
                {/*<label>Email Id</label>*/}
                <span id="red">&nbsp;</span>
                <input
                  type="text"
                  value={this.state.user.email}
                  placeholder="Email id"
                  onChange={this.handleChangeUemail.bind(this)}
                />
              </div>

              <div className="form-group">
                {/*<label>Mobile Number</label>*/}
                <span id="red">*</span>
                <input
                  type="number"
                  value={this.state.user.mobile}
                  placeholder="Mobile Number"
                  onChange={this.handleChangeUmobile.bind(this)}
                />
              </div>

              <div className="form-group">
                {/*<label>Address</label>*/}
                <span id="red">&nbsp;</span>
                <input
                  type="text"
                  value={this.state.user.address}
                  placeholder="Address"
                  onChange={this.handleChangeUaddress.bind(this)}
                />
              </div>

              <div className="form-group">
                {/*<label>Purpose of visit</label>*/}
                <span id="red">&nbsp;</span>
                <input
                  type="text"
                  value={this.state.user.purpose}
                  placeholder="Purpose of visit"
                  onChange={this.handleChangeUpurpose.bind(this)}
                />
              </div>

              <div className="form-group">
                {/*<label>date Of Visit</label>*/}
                <span id="red">*</span>
                <input
                  type="date"
                  value={this.state.user.date}
                  placeholder="date Of Visit"
                  onChange={this.handleChangeUdate.bind(this)}
                />
              </div>

            <button className="btn btn-primary btn-md"
              block
              type="submit" onClick={this.login.bind(this)}>
              Login
            </button>
          </form>
        </div>
        </div>
        );
    }




    /*After successful registration display the Customer's Visit Information*/
    else{
      return(
        <div className="panel info">
          <div className="panel-heading panel-primary">
            <h2>Customer's Visit Information</h2>
          </div>
          <div className="panel-body">
            <h4>Name: {this.state.user.name}</h4>
            <h4>Email Id: {this.state.user.email || '--NA--'}</h4>
            <h4>Mobile Number: {this.state.user.mobile}</h4>
            <h4>Address: {this.state.user.address || '--NA--'}</h4>
            <h4>Description/Purpose: {this.state.user.purpose || '--NA--'}</h4>
            <h4>Date of Visit: {this.state.user.date}</h4>
            <button onClick={this.delete.bind(this)} className='btn btn-danger delete'>Delete</button>
          </div>
        </div>
      );
    }
  }
}

export default App;
