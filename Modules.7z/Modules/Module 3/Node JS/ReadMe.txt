Browser-based
Using the Postman


Using port No. 3000


-->To Display all mobiles use "get method" with the url
http://localhost:3000/displayMobiles

-->To Display Mobiles belonging in the range 10,000 to 50,000 use "get method" with the url
http://localhost:3000/priceDisplay

-->To Update mobile name based on id use "put method" with the url
http://localhost:3000/updateName/:id
and body parameters in the encoded form as
"name":" __newName__"

-->To Add a new Mobile use "post method" with the url
http://localhost:3000/addMobile
and body parametes in the encoded form as
{"id":"__newId__",
"name":" __newName__",
"price":"__newPrice__"
}


