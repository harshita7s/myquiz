const fs=require('fs');
const express=require('express');
const bodyParser=require('body-parser');

const app=express();
let mobileJson=fs.readFileSync('mobile.json');
let mobile=JSON.parse(mobileJson);


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

//Displaying index page
app.get('/',(req,res)=>{
    fs.readFile('index.html', function(err, data) {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
    });
});



/*---------------SECTION 1.1----------------------------*/
//Displaying all the data fetched from the json array
app.get('/displayMobiles',(req,res)=>{
    res.send(mobile);
})



/*---------------SECTION 1.2----------------------------*/
//Displaying mobiles belonging to the specific range from 10,000 to 50,000
app.get('/priceDisplay',(req,res)=>{
    var mblArr=[];
    for(let m of mobile){
        if((m.mobPrice>10000) && (m.mobPrice<50000) )
            mblArr.push(m);
    };
    res.send(mblArr);
})



/*---------------SECTION 1.3----------------------------*/
//Updating mobile name based on mobile Id - 1002
app.put('/updateName/:id',(req,res)=>{
    let mbl;
    id=req.params['id'];
    //console.log(req.body.name);
    for(let m of mobile){
        if(m.mobId==id){
            m.mobName=req.body.name;
            mbl=m;
            break;
        }
    }
    let data = JSON.stringify(mobile,null,2);  
    fs.writeFileSync('mobile.json', data);  
    res.send(mbl);
})



/*---------------SECTION 1.4----------------------------*/
//Adding a new mobile
app.post('/addMobile',(req,res)=>{
    let mbl={
        "mobId": parseInt(req.body.id),
        "mobName": req.body.name,
        "mobPrice": parseFloat(req.body.price),
    }
    mobile.push(mbl);
    let data=JSON.stringify(mobile,null,2);
    fs.writeFileSync('mobile.json',data);
    res.send(mbl);
});

app.listen(3000,()=>{
    console.log("Server is running on port 3000");
})
