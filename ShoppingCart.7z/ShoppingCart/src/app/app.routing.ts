import {CartComponent} from './cart/cart.Component';
import {ProductComponent} from './product/product.component';
import {WelcomeComponent} from './welcome/welcome.component';
import {LoginPageComponent} from './login-page/login-page.component'

export const AppRoutes: any =[
    {path:"", component:LoginPageComponent},
    {path:"welcome", component:WelcomeComponent},
    {path:"cart", component:CartComponent},
    {path:"product", component:ProductComponent},


];

export const AppComponents: any =[
    CartComponent,
    ProductComponent,
    WelcomeComponent,
    LoginPageComponent
];
