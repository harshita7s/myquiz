import { Grocery } from './grocery';

export const GROCERIES: Grocery[] = [
  { id: 3331, 
    product: 'Coffee',
   price:20,
    discount:'20 %',
   imageUrl:'https://images.pexels.com/photos/1002649/pexels-photo-1002649.jpeg?auto=compress&cs=tinysrgb&h=350'},
  { id: 3332,
     product: 'Wheat',
      price:40,
       discount:'15 %',
       imageUrl:'https://images.pexels.com/photos/5765/flour-powder-wheat-jar.jpg?auto=compress&cs=tinysrgb&h=350' },
  { id: 3333,
     product: 'Fruits', 
     price:50, 
     discount:'15 %',
     imageUrl:'https://images.pexels.com/photos/1132047/pexels-photo-1132047.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940' },
  { id: 3334,
     product: 'Vegetables', 
     price:70,
      discount:'10 %',
      imageUrl:'https://images.pexels.com/photos/36740/vegetables-vegetable-basket-harvest-garden.jpg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940' }
]