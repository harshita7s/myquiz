export class Product{
    id: number;
    product:string;
    price: number;
   imageUrl:string;
}