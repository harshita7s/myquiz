import { IClothing } from '../clothing/cloth';

export const CLOTHING: IClothing[] = [
  { id: 1111, product: 'Dress', price:350, discount:'20 %',description:'women dress materials',imageUrl:'assets/image/dress.jpg'},
  { id: 1112, product: 'Top', price:400, discount:'15 %',description:'Prisma',imageUrl:'assets/image/top.jpg' },
  { id: 1113, product: 'Sarees', price:1000, discount:'15 %',
  description: 'Silk sarees',imageUrl:'assets/image/saree.jpg' }
]




