export interface IClothing {
    id: number;
    product:string;
    discount:string;
    price: number;
    description: string;
    imageUrl: string;
   
  

}