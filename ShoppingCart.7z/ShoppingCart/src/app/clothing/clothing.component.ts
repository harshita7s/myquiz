import { Component, OnInit } from '@angular/core';
import {IClothing} from './cloth';

import {ProductService} from '../product.service'
@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent implements OnInit {
pageTitle="Clothing List";
 Cloth:IClothing[];
  imageWidth:number=200;
  imageHeight:number=150;
  cartProductsId:number[];
  constructor(private productService:ProductService) { }
  getClothing():void
  {
    this.Cloth=this.productService.getClothing();
  }
  ngOnInit() {
    this.getClothing();
    this.cartProductsId=this.productService.getCartProductsId();
  }
  addToCart(proid,proName,proPrice,proImage){
  this.productService.addProduct(proid,proName,proPrice,proImage);
  this.cartProductsId=this.productService.getCartProductsId();
  }
  removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.cartProductsId=this.productService.getCartProductsId();
}
}
