import { Component, OnInit, Input,Output, EventEmitter  } from '@angular/core';
import {CourseServiceService} from '../course-service.service';
import {COURSE} from '../course';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-update-modal',
  templateUrl: './update-modal.component.html',
  styleUrls: ['./update-modal.component.css']
})
export class UpdateModalComponent implements OnInit {

  constructor(private courseService:CourseServiceService) { }
  @Input() id:number;
  @Input() name:string;
  @Input() time:string;
  @Input() durtn:number;
  @Input() price:number;

  ngOnInit() {
  }

  

  course: COURSE;
  @Output() updateEvent = new EventEmitter<COURSE>();



  resetForm(form:NgForm){
    form.resetForm();
  }
  updateCourseDetails(){
    console.log("Update Called");
    this.course={
      id:this.id,
      name:this.name,
      price:this.price,
      duration:this.durtn,
      time:this.time
    }
    this.updateEvent.emit(this.course)
  }
}
