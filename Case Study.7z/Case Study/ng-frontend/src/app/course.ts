export class COURSE{
    id: number;
    name: string;
    price: number;
    duration: number;
    time: string;
}