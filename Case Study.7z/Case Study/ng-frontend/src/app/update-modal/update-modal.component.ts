import { Component, Input,Output, EventEmitter } from '@angular/core';
import {CourseServiceService} from '../course-service.service';
import {COURSE} from '../course';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-update-modal',
  templateUrl: './update-modal.component.html',
  styleUrls: ['./update-modal.component.css']
})
export class UpdateModalComponent {

  constructor(private courseService:CourseServiceService) { }
  @Input() id:number;
  @Input() name:string;
  @Input() time:string;
  @Input() durtn:number;
  @Input() price:number;


  course: COURSE;
  @Output() updateEvent = new EventEmitter<COURSE>();

  resetForm(){
  }
  updateCourseDetails(){
    console.log("Update Called ");
    this.course={
      id:this.id,
      name:this.name,
      price:this.price,
      duration:this.durtn,
      time:this.time
    }
    this.updateEvent.emit(this.course)
  }
}
