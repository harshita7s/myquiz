import { Injectable } from '@angular/core';
import {COURSE} from './course';

import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs'

 
@Injectable({
  providedIn: 'root'
})

export class CourseServiceService {
  url="http://localhost:3000";
  constructor(private httpClient:HttpClient) { }

  getCourseData(){
    return this.httpClient.get<COURSE[]>(this.url+"/getCourses");
  }

  deleteCourse(id){
    return this.httpClient.delete<COURSE[]>(this.url+"/delete/"+id);
  }

  updateCourseData(id:number,name:string,price:number,duration:number,time:string){
    console.log("Update Service Called");
    var obj={id:id,name:name,price:price,duration:duration,time:time}
    return this.httpClient.put<COURSE[]>(this.url+"/updateCourse",obj);
  }

  searchCourse(id){
    return this.httpClient.get<COURSE>(this.url+"/searchCourse/"+id);
  }
}
