import { Component, OnInit } from '@angular/core';
import { ConnectionService } from '../connection.service'

@Component({
  selector: 'app-my-networks',
  templateUrl: './my-networks.component.html',
  styleUrls: ['./my-networks.component.css']
})
export class MyNetworksComponent implements OnInit {

  user: String = "Nandkumar";
  connectionsCount: String="0";
  invitationsReceivedCount: String;
  invitationsReceived: any[] = [];
  constructor(private connService: ConnectionService) { }

  getConnectionCount() {
    this.connService.getConnectionCount(this.user).subscribe((data) => {
      let x = JSON.stringify(data);
      this.connectionsCount = x;
    });
  }

  getInvitationReceivedCount() {
    this.connService.getInvitationReceivedCount(this.user).subscribe((data) => {
      let x = JSON.stringify(data);
      this.invitationsReceivedCount = eval(x);
    })
  }

  getInvitationReceivedList() {
    this.connService.getReceivedInvitationsList(this.user).subscribe((data) => {
      let count = 0;
      for (let d of <string>data) {
        if (count < 3) {
          this.invitationsReceived.push(d);
          count++;
        }
      }
    });
  }

  ngOnInit() {
    this.invitationsReceived = [];
    this.getConnectionCount();
    this.getInvitationReceivedCount();
    this.getInvitationReceivedList();
  }

  acceptInvitation(requester){
    this.connService.acceptInvitation(this.user,requester).subscribe((data)=>{
      for(let i of this.invitationsReceived){
        if(i._id==requester){
          let index=this.invitationsReceived.indexOf(i);
          this.invitationsReceived.splice(index,1);
        }
      }
      this.getInvitationReceivedCount();
      this.getConnectionCount();
    });
  }

  ignoreInvitation(sender){
    this.connService.ignoreInvitation(this.user,sender).subscribe((data)=>{
      for(let i of this.invitationsReceived){
        if(i._id==sender){
          let index=this.invitationsReceived.indexOf(i);
          this.invitationsReceived.splice(index,1);
        }
      }
      this.getInvitationReceivedCount();
    });
  }

}