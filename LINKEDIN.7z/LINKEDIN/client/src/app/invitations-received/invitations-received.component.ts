import { Component, OnInit } from '@angular/core';
import { ConnectionService } from '../connection.service';

@Component({
  selector: 'app-invitations-received',
  templateUrl: './invitations-received.component.html',
  styleUrls: ['./invitations-received.component.css']
})
export class InvitationsReceivedComponent implements OnInit {

  user:String="Nandkumar";
  invitationsReceivedCount: Number=0;
  invitationsReceived:any[]=[];
  constructor(private connService: ConnectionService) { }

  getInvitationReceivedCount() {
    this.connService.getInvitationReceivedCount(this.user).subscribe((data) => {
      let x = JSON.stringify(data);
      this.invitationsReceivedCount = eval(x);
    })
  }

  getInvitationReceivedList() {
    this.connService.getReceivedInvitationsList(this.user).subscribe((data) => {
      for(let d of <string>data){
        this.invitationsReceived.push(d);
      }
    });
  }

  ngOnInit() {
    this.invitationsReceived=[];
    this.getInvitationReceivedCount();
    this.getInvitationReceivedList();
  }

  acceptInvitation(requester){
    this.connService.acceptInvitation(this.user,requester).subscribe((data)=>{
      for(let i of this.invitationsReceived){
        if(i._id==requester){
          let index=this.invitationsReceived.indexOf(i);
          this.invitationsReceived.splice(index,1);
        }
      }
      this.getInvitationReceivedCount();
    });
  }

  ignoreInvitation(sender){
    this.connService.ignoreInvitation(this.user,sender).subscribe((data)=>{
      for(let i of this.invitationsReceived){
        if(i._id==sender){
          let index=this.invitationsReceived.indexOf(i);
          this.invitationsReceived.splice(index,1);
        }
      }
      this.getInvitationReceivedCount();
    });
  }
}
