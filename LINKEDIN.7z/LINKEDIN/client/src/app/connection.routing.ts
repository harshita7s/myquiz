import { MyNetworksComponent } from './my-networks/my-networks.component';
import { MyConnectionsComponent } from './my-connections/my-connections.component';
import { MyInvitationsComponent } from './my-invitations/my-invitations.component';
import { InvitationsReceivedComponent } from './invitations-received/invitations-received.component';
import { InvitationsSentComponent } from './invitations-sent/invitations-sent.component';
import {BlockListComponent} from './block-list/block-list.component'
import { AppComponent } from './app.component';

export const ConnectionRoutes: any = [
    { path: "", component: MyNetworksComponent },
    { path: "my-connections", component: MyConnectionsComponent },
    {path: 'my-invitations',component: MyInvitationsComponent,
        children: [
            {path: 'sent',component: InvitationsSentComponent},
            {path: 'received',component: InvitationsReceivedComponent},
            {path:'block-list',component:BlockListComponent}]
    }
];

export const ConnectionComponents: any = [
    MyNetworksComponent,
    MyConnectionsComponent,
    MyInvitationsComponent,
    InvitationsReceivedComponent,
    InvitationsSentComponent,
    BlockListComponent
];
