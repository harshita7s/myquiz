import { Component, OnInit } from '@angular/core';
import { ConnectionService } from '../connection.service'

@Component({
  selector: 'app-my-connections',
  templateUrl: './my-connections.component.html',
  styleUrls: ['./my-connections.component.css']
})
export class MyConnectionsComponent implements OnInit {

  user: String = "Nandkumar";
  connectionsCount: String;
  connections: any[] = [];
  constructor(private connService: ConnectionService) { }

  getConnectionCount() {
    this.connService.getConnectionCount(this.user).subscribe((data) => {
      let x = JSON.stringify(data);
      this.connectionsCount = x;
    });
  }

  getConnectionsList() {
    this.connService.getConnectionsList(this.user).subscribe((data) => {
      for (let d of <string>data) {
        this.connections.push(d);
      }
    });
  }

  ngOnInit() {
    this.connections=[];
    this.getConnectionCount();
    this.getConnectionsList();
  }

  removeConnection(connection) {
    this.connService.removeConnection(this.user, connection).subscribe((data) => {
      for (let i of this.connections) {
        if (i._id == connection) {
          let index = this.connections.indexOf(i);
          this.connections.splice(index, 1);
        }
      }
      this.getConnectionCount();
    });
  }

  blockConnection(blockee){
    this.connService.blockConnection(this.user, blockee).subscribe((data) => {
      for (let i of this.connections) {
        if (i._id == blockee) {
          let index = this.connections.indexOf(i);
          this.connections.splice(index, 1);
        }
      }
      this.removeConnection(blockee);
    });
  }

}
