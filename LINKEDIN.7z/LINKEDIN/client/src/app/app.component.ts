import { Component,OnInit } from '@angular/core';
import {ConnectionService} from './connection.service'
import {USER} from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  userData:USER;
  user:String="Nandkumar"
  constructor(private connService:ConnectionService){

  }
  ngOnInit(){
    this.connService.getUserData(this.user).subscribe((data)=>{this.userData=data[0]});
  }
}
