import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MyNetworksComponent } from './my-networks/my-networks.component';
import { MyConnectionsComponent } from './my-connections/my-connections.component';
import { MyInvitationsComponent } from './my-invitations/my-invitations.component';
import { InvitationsReceivedComponent } from './invitations-received/invitations-received.component';
import { InvitationsSentComponent } from './invitations-sent/invitations-sent.component';

import {FormsModule} from '@angular/forms'

import { RouterModule } from "@angular/router";
import { ConnectionComponents, ConnectionRoutes } from "./connection.routing";

import { HttpClientModule } from '@angular/common/http';
import {ConnectionService} from "./connection.service";
import { BlockListComponent } from './block-list/block-list.component';

@NgModule({
  declarations: [
    AppComponent,
    MyNetworksComponent,
    MyConnectionsComponent,
    MyInvitationsComponent,
    InvitationsReceivedComponent,
    InvitationsSentComponent,
    ...ConnectionComponents,
    BlockListComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    HttpClientModule,
    RouterModule.forRoot(ConnectionRoutes)
  ],
  providers: [ConnectionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
