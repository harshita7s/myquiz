var i=1;
var jsonObj;
var queDiv;
var questionId;
var choiceId = new Array();
var choice1SpanId;
var choice2SpanId;
var choice3SpanId;
var choice4SpanId;
var previousBtnId;
var marks=0,count=0;
function validate(){
			$.get("credentials.json",
					function(a,b){
					var jsonObj=JSON.parse(a);
					var txtName=document.getElementById("txtUserNameId").value;
					var txtPwd=document.getElementById("pwdId").value;
					var flag=0;
					for(var i=0;i<jsonObj.length;i++){
						var uName=jsonObj[i].name;
						var pwd=jsonObj[i].pwd;
						if(txtName==uName && txtPwd==pwd){
							alert("Login Successful...")
							$('#div1').load("QuizPage.html")
							flag=1;
							break;
						}
					}
					if(flag==0){
					alert("Wrong Username/password! Try Again")
					$('#div1').load("Index.html")
					}
			});
			return false;
		}

function startQuiz(){
	var chkbx=document.getElementById("agreeChkBxId").checked;
	if(chkbx){
		$.get("questionDb.json",
				function(a,b){
				jsonObj=JSON.parse(a);	
		});
		$('#div1').load("QuestionsPage.html",function(){
			queDiv= document.getElementById("queId");
			queDiv.innerHTML="QUESTION "+i;
			var que=jsonObj[0].que;
			questionId=document.getElementById("questionId");
			questionId.innerHTML=que;
			choiceId[0]=document.getElementById("choice1Id");
			choiceId[0].value=jsonObj[0].choice1;
			choice1SpanId=document.getElementById("choice1SpanId");
			choice1SpanId.innerHTML=jsonObj[0].choice1;
			choiceId[1]=document.getElementById("choice2Id");
			choiceId[1].value=jsonObj[0].choice2;
			choice2SpanId=document.getElementById("choice2SpanId");
			choice2SpanId.innerHTML=jsonObj[0].choice2;
			choiceId[2]=document.getElementById("choice3Id");
			choiceId[2].value=jsonObj[0].choice3;
			choice3SpanId=document.getElementById("choice3SpanId");
			choice3SpanId.innerHTML=jsonObj[0].choice3;
			choiceId[3]=document.getElementById("choice4Id");
			choiceId[3].value=jsonObj[0].choice4;
			choice4SpanId=document.getElementById("choice4SpanId");
			choice4SpanId.innerHTML=jsonObj[0].choice4;
			previousBtnId=document.getElementById("previousBtnId");
			previousBtnId.disabled=true;
		});
	}
	else
		{
			alert("Please Agree to the t&c");
			return false;
		}
}

/*function previousQue(){
	i--;
	if(i>0){
		queDiv.innerHTML="QUESTION "+i;
		var que=jsonObj[i-1].que;
		questionId.innerHTML=que;
		for(var j=0;j<4;j++){
			if(choiceId[i].checked){
				choiceId[i].checked=false;
				break;
			}
		}
		choiceId[0].value=jsonObj[i-1].choice1;
		choice1SpanId.innerHTML=jsonObj[i-1].choice1;
		choiceId[1].value=jsonObj[i-1].choice2;
		choice2SpanId.innerHTML=jsonObj[i-1].choice2;
		choiceId[2].value=jsonObj[i-1].choice3;
		choice3SpanId.innerHTML=jsonObj[i-1].choice3;
		choiceId[3].value=jsonObj[i-1].choice4;
		choice4SpanId.innerHTML=jsonObj[i-1].choice4;
		if(i==1)
			previousBtnId.disabled=true;
	}
}*/

function nextQue(){
	i++;
	if(i==6){
		for(var j=0;j<4;j++){
			if(choiceId[j].checked){
				choiceId[j].checked=false;
				if(choiceId[j].value === jsonObj[i-2].ans){
					marks++;
				}
				break;
			}
		}
		$('#div1').load("Submit.html",function(){
			if(marks>3){
				document.getElementById("box-1").style.backgroundColor="lightgreen";
				document.getElementById("marksId").innerHTML="Congratulations<br/>You have scored "+marks+" out of 5."
			}
			else{
				document.getElementById("box-1").style.backgroundColor="pink";
				document.getElementById("marksId").innerHTML="Sorry!<br/>You have scored "+marks+" out of 5."
			}
		});
	}
	else{
		queDiv.innerHTML="QUESTION "+i;
		var que=jsonObj[i-1].que;
		questionId.innerHTML=que;
		for(var j=0;j<4;j++){
			if(choiceId[j].checked){
				choiceId[j].checked=false;
				if(choiceId[j].value === jsonObj[i-2].ans){
					marks++;
				}
				break;
			}
		}
		choiceId[0].value=jsonObj[i-1].choice1;
		choice1SpanId.innerHTML=jsonObj[i-1].choice1;
		choiceId[1].value=jsonObj[i-1].choice2;
		choice2SpanId.innerHTML=jsonObj[i-1].choice2;
		choiceId[2].value=jsonObj[i-1].choice3;
		choice3SpanId.innerHTML=jsonObj[i-1].choice3;
		choiceId[3].value=jsonObj[i-1].choice4;
		choice4SpanId.innerHTML=jsonObj[i-1].choice4;
		//previousBtnId.disabled=false;
		if(i==5)
			document.getElementById("nextBtnId").value="Submit";
	}
}