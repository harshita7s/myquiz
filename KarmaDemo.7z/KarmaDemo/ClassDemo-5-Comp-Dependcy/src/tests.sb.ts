// Import spec files individually for Stackblitz
import './app/simple-test/auth.service.spec.ts';
import './app/simple-test/login.service.spec.ts';
