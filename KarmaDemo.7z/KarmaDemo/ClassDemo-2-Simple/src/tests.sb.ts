// Import spec files individually for Stackblitz
import './app/simple-test/greet.spec.ts';
import './app/simple-test/compute.spec.ts';
import './app/simple-test/city.service.spec.ts';
import './app/simple-test/auth.service.spec.ts';
