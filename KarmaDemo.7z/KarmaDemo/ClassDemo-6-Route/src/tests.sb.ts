// Import spec files individually for Stackblitz
import './app/router.spec.ts';