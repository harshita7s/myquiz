// Import spec files individually for Stackblitz
import './app/app.component.spec.ts';